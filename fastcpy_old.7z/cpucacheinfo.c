﻿#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* 此文件相关实现有问题, 仅作为参考！！！ */

#ifndef INLINE
# if defined(__clang__) || defined(__GNUC__) || defined(__GNUG__)
#   define INLINE __inline__ __attribute__((always_inline))
# elif defined(_MSC_VER)
#   define INLINE __forceinline
# else
#   define INLINE inline
# endif
#endif

#ifndef NOINLINE
# if defined(__clang__) || defined(__GNUC__) || defined(__GNUG__)
#   define NOINLINE __attribute__((__noinline__))
# elif defined(_MSC_VER)
#   define NOINLINE __noinline
# else
#   define NOINLINE
# endif
#endif

#ifndef xsun_likely
# if defined(__GNUC__) && defined(__has_builtin) && __has_builtin(__builtin_expect)
#   define xsun_likely(x) __builtin_expect(!!(x), 1)
# elif defined(__has_cpp_attribute) && __has_cpp_attribute(likely)
#   define xsun_likely(x) \
    ([](long a) -> long { if(a) [[likely]] return 1; return 0; })(x)
# else
#   define xsun_likely(x) (!!(x))
# endif
#endif

#ifndef xsun_unlikely
# define xsun_unlikely(x) (!xsun_likely(!(x)))
#endif

#define __ASM_OPT(...) #__VA_ARGS__
#define ASM_OPT(...) __ASM_OPT(__VA_ARGS__)

size_t fastcpy_non_temporal_threshold = 0xffffffffffffffffLL;

uint32_t g_l2cache = 0;
uint32_t g_l3cache = 0;
uint32_t g_cpu_counts = 0;

#ifndef __cpuid
#define __cpuid(level, a, b, c, d)					\
  __asm__ __volatile__ ("cpuid\n\t"					\
			: "=a" (a), "=b" (b), "=c" (c), "=d" (d)	\
			: "0" (level))
#endif
#ifndef __cpuid_count
#define __cpuid_count(level, count, a, b, c, d)				\
  __asm__ __volatile__ ("cpuid\n\t"					\
			: "=a" (a), "=b" (b), "=c" (c), "=d" (d)	\
			: "0" (level), "2" (count))
#endif

#define CPU_VENDOR_TO_INT32(a,b,c,d, e,f,g,h, i,j,k,l) \
	(((a^e^i)&0xff)+(((b^f^j)&0xff)<<8)+(((c^g^k)&0xff)<<16)+(((d^h^l)&0xff)<<24))

/**
 * 通过 cpuid 指令查询 L2 L3 cache 与 logical CPUs 设置 fastcpy_non_temporal_threshold
 *  cpuid 参考: https://www.sandpile.org/x86/cpuid.htm
 *  glibc 参考: https://sourceware.org/git/?p=glibc.git;a=blob;f=sysdeps/x86/cacheinfo.c;hb=d3c57027470b78dba79c6d931e4e409b1fecfc80
 *  libcpuid 参考: https://libcpuid.sourceforge.net/documentation.html
 */
__attribute__((used,optimize("align-functions=32")))
NOINLINE static void get_non_temporal_threshold(void *dst, const void *src, size_t size) {
	// fastcpy_non_temporal_threshold = (L2 cache + L3 cache) * 4 / (CPUs * 3)
	const uint32_t intel_vendor = CPU_VENDOR_TO_INT32('G','e','n','u','i','n','e','I','n','t','e','l');
	const uint32_t amd_vendor = CPU_VENDOR_TO_INT32('A','u','t','h','e','n','t','i','c','A','M','D');
	const static uint32_t amd_cache_assoc[16] = {
		0, 1, 2, 3, 4, 6, 8, 0,
		16, 0, 32, 48, 64, 96, 128, 0
	};
	size_t movnt_threshold;
	size_t cpu_count_id = 0x200000;// cpuid 于 x86-64 总是可用
	//asm volatile("pushf\n\tpop %0\n\t":"=r"(cpu_count_id):);
	if(xsun_likely(cpu_count_id & 0x200000)) {// 使用 cpuid 获取参数
		register uint32_t eax, ebx, ecx, edx;
		__cpuid(0, eax, ebx, ecx, edx);
		uint32_t vendor_id = ebx ^ edx ^ ecx;
		cpu_count_id = movnt_threshold = 0;
		do {
			if(vendor_id == intel_vendor) {// intel cpu
				if(xsun_unlikely(eax < 4)) break;// leaf 2 仅旧 CPU 暂不支持
				else if(xsun_likely(eax >= 0xb)) {// leaf 11
					for(int i = 0; i < 4; ++i) {// 仅执行四次即可
						__cpuid_count(0xb, i, eax, ebx, ecx, edx);
						int32_t type = ecx & 0xff00;
						if(type == 0) break;
						if(type == 0x200) {// 逻辑核心级别
							g_cpu_counts = cpu_count_id = ebx & 0xff;// 逻辑核心数
							break;
						}
					}
				}
				for(int i = 0; i < 8; ++i) {// leaf 4
					__cpuid_count(4, i, eax, ebx, ecx, edx);
					if((eax & 0x1F) == 0) break;
					if((eax & 0xe0) >= 0x40) {// 只计算 L2 以上的缓存
						int32_t ways = (ebx >> 22) + 1;
						int32_t parts = (ebx << 10 >> 22) + 1;
						int32_t sets = ecx + 1;
						int32_t bytes = (ebx & 0xfff) + 1;
						if((eax & 0xe0) == 0x40) g_l2cache = (bytes * parts) * (sets * ways);
						if((eax & 0xe0) == 0x60) g_l3cache = (bytes * parts) * (sets * ways);
						movnt_threshold += (bytes * parts) * (sets * ways);
					}
				}
			}
			else if(vendor_id == amd_vendor) {// amd cpu
				__cpuid(0x80000000, eax, ebx, ecx, edx);
				if(xsun_unlikely(eax < 0x80000006)) break;// 不支持置默认值
				if(xsun_likely(eax >= 0x80000026)) {// leaf 8000_0026h
	/* https://www.coelacanth-dream.com/posts/2022/10/19/amd64-rev3_34-cpuid/ */
					for(int i = 0; i < 6; ++i) {// 类似 leaf 11
						__cpuid_count(0x80000026, i, eax, ebx, ecx, edx);
						int32_t type = ecx & 0xff00;
						if(type == 0) break;
						if(type == 0x300) {// Die 级别
							g_cpu_counts = cpu_count_id = ebx & 0xff;// 逻辑核心数
							break;
						}
					}
					goto Leaf_8000_001Dh;
				}
				if(xsun_likely(eax >= 0x8000001d)) {// leaf 8000_001Dh
Leaf_8000_001Dh:
					for(int i = 0; i < 8; ++i) {// 类似 leaf 4
						__cpuid_count(0x8000001d, i, eax, ebx, ecx, edx);
						if((eax & 0x1F) == 0) break;
						if((eax & 0xe0) >= 0x40) {// 只计算 L2 以上的缓存
							int32_t ways = (ebx >> 22) + 1;
							int32_t parts = (ebx << 10 >> 22) + 1;
							int32_t sets = ecx + 1;
							int32_t bytes = (ebx & 0xfff) + 1;
							if((eax & 0xe0) == 0x40) g_l2cache = (bytes * parts) * (sets * ways);
							if((eax & 0xe0) == 0x60) g_l3cache = (bytes * parts) * (sets * ways);
							movnt_threshold += (bytes * parts) * (sets * ways);
						}
					}
					if(xsun_unlikely(cpu_count_id == 0)) goto Leaf_8000_0008h;
					else if(movnt_threshold >= 127) break;
				}
				if(xsun_likely(eax >= 0x80000008)) {// leaf 8000_0008h
Leaf_8000_0008h:
					__cpuid(0x80000008, eax, ebx, ecx, edx);
					/* Get width of APIC ID.  */
					g_cpu_counts = cpu_count_id = 1 << ((ecx >> 12) & 0x0f);
					if(movnt_threshold >= 127) break;
				}
				// leaf 8000_0006h
				__cpuid(0x80000006, eax, ebx, ecx, edx);
				int32_t l2cache = amd_cache_assoc[(ecx >> 12) & 0xf];
				if(l2cache == 0) break;
				l2cache *= ecx >> 16 << 10;
				ecx = (edx >> 12) & 0xf;
				int32_t l3cache = amd_cache_assoc[ecx];
				if(l3cache == 0) {
					if(ecx == 0) break;
					l3cache = edx >> 18 << 19;
				}
				else l3cache *= edx >> 18 << 19;
				movnt_threshold = (g_l2cache = l2cache) + (g_l3cache = l3cache);
			}
		} while(0);
		if(cpu_count_id == 0) {// leaf 0xb 获取 CPU 逻辑CPU 数量
			__cpuid(1, eax, ebx, ecx, edx);
			g_cpu_counts = cpu_count_id = (ebx << 8 >> 24);// 适用于旧 CPU, 为逻辑CPU数量
		}
		if(movnt_threshold < 127 || cpu_count_id == 0) movnt_threshold = 0x200000;
		else movnt_threshold = movnt_threshold * 4 / (3 * cpu_count_id);
	}
	else movnt_threshold = 0x200000;// 默认 2 MB
	fastcpy_non_temporal_threshold = movnt_threshold;
	asm volatile(ASM_OPT(
		mov 	%[dst], %%rax\n\t
		//jmp 	.F_more_8x_vec\n\t
		):
#ifdef XMM_NEED_SAVE/* ms_abi */
		: [dst]"rcx"(dst), [src]"rdx"(src), [size]"r8"(size)
#else/* sysv_abi */
		: [dst]"rdi"(dst), [src]"rsi"(src), [size]"rdx"(size)
#endif
		: "rax"
	);
}


int main() {
	get_non_temporal_threshold(NULL, NULL, 0);
	printf("cpus %d, l2cache = %u, l3cache = %u, ntsd = %llu\n", g_cpu_counts, g_l2cache, g_l3cache, fastcpy_non_temporal_threshold);
	return 0;
}


