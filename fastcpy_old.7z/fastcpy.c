﻿
#include "fastcpy.h"

#include <stdint.h>
#include <immintrin.h>

/* 注意: 此文件仅能在 x86-64 平台上的 gcc 编译 */

/* AVX 版本的 fastcpy_big 实现, 用于内联函数, 禁止外部调用 */
#if !defined(FASTCPY_USE_CMOV)
__attribute__((target("arch=x86-64-v3")))
#else
__attribute__((always_inline,target("arch=x86-64-v3"))) inline
#endif
void* _AVX_fastcpy_big(void *dest, const void* src, size_t size) {
	return __builtin_memcpy(dest, src, size);
}

/* SSE 版本的 fastcpy_big 实现, 用于内联函数, 禁止外部调用 */
#if !defined(FASTCPY_USE_CMOV)
__attribute__((target("arch=x86-64-v3")))
#else
__attribute__((always_inline,target("arch=x86-64-v2"))) inline
#endif
void* _SSE_fastcpy_big(void *dest, const void* src, size_t size) {
	return __builtin_memcpy(dest, src, size);
}


/*
 * 微软 x64 传参约定：
 * @1   rcx xmm0
 * @2   rdx xmm1
 * @3   r8  xmm2
 * @4   r9  xmm3
 * @5+  stack
 *
 * GNU汇编器伪指令(GNU assembler directives):
 * https://sourceware.org/binutils/docs/as/Pseudo-Ops.html
 */

/**
 * 超小尺寸的 memcpy 快速实现, 是一组对齐地址的函数, 请勿直接调用!
 * 相比于跳表实现, 这省略了跳表数据, 从而免受内存复制时数据缓存的影响
 */
__attribute__((optimize("align-functions=32"),target("arch=x86-64-v3"))) void _AVX_fastcpy_tiny(void *dest, const void* src, size_t size) {
	// dest %0, src %1, size %2, %%rax, %%r9, 每组指令对齐 32 字节
	asm volatile(
		"0:\n\t" /* size = 0 */
		"ret\n\t"
		".p2align 5\n\t"
		"1:\n\t" /* size = 1 */
		"movzbl (%1), %%eax\n\t"
		"movb %%al, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"2:\n\t" /* size = 2 */
		"movzwl (%1), %%eax\n\t"
		"movw %%ax, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"3:\n\t" /* size = 3 */
		"movzwl (%1), %%r9d\n\t"
		"movzbl 2(%1), %%eax\n\t"
		"movw %%r9w, (%0)\n\t"
		"movb %%al, 2(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"4:\n\t" /* size = 4 */
		"movl (%1), %%eax\n\t"
		"movl %%eax, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"5:\n\t" /* size = 5 */
		"movl (%1), %%r9d\n\t"
		"movzbl 4(%1), %%eax\n\t"
		"movl %%r9d, (%0)\n\t"
		"movb %%al, 4(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"6:\n\t" /* size = 6 */
		"movl (%1), %%r9d\n\t"
		"movzwl 4(%1), %%eax\n\t"
		"movl %%r9d, (%0)\n\t"
		"movw %%ax, 4(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"7:\n\t" /* size = 7 */
		"movl (%1), %%r9d\n\t"
		"movl 3(%1), %%eax\n\t"
		"movl %%r9d, (%0)\n\t"
		"movl %%eax, 3(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"8:\n\t" /* size = 8 */
		"movq (%1), %%rax\n\t"
		"movq %%rax, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"9:\n\t" /* size = 9 */
		"movq (%1), %%r9\n\t"
		"movzbl 8(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movb %%al, 8(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"10:\n\t" /* size = 10 */
		"movq (%1), %%r9\n\t"
		"movzwl 8(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movw %%ax, 8(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"11:\n\t" /* size = 11 */
		"movq (%1), %%r9\n\t"
		"movl 7(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movl %%eax, 7(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"12:\n\t" /* size = 12 */
		"movq (%1), %%r9\n\t"
		"movl 8(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movl %%eax, 8(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"13:\n\t" /* size = 13 */
		"movq (%1), %%r9\n\t"
		"movq 5(%1), %%rax\n\t"
		"movq %%r9, (%0)\n\t"
		"movq %%rax, 5(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"14:\n\t" /* size = 14 */
		"movq (%1), %%r9\n\t"
		"movq 6(%1), %%rax\n\t"
		"movq %%r9, (%0)\n\t"
		"movq %%rax, 6(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"15:\n\t" /* size = 15 */
		"movq (%1), %%r9\n\t"
		"movq 7(%1), %%rax\n\t"
		"movq %%r9, (%0)\n\t"
		"movq %%rax, 7(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"16:\n\t" /* size = 16 */
		"vmovups (%1), %%xmm0\n\t"
		"vmovups %%xmm0, (%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"17:\n\t" /* size = 17 */
		"vmovups (%1), %%xmm0\n\t"
		"movzbl 16(%1), %%eax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movb %%al, 16(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"18:\n\t" /* size = 18 */
		"vmovups (%1), %%xmm0\n\t"
		"movzwl 16(%1), %%eax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movw %%ax, 16(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"19:\n\t" /* size = 19 */
		"vmovups (%1), %%xmm0\n\t"
		"movl 15(%1), %%eax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movl %%eax, 15(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"20:\n\t" /* size = 20 */
		"vmovups (%1), %%xmm0\n\t"
		"movl 16(%1), %%eax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movl %%eax, 16(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"21:\n\t" /* size = 21 */
		"vmovups (%1), %%xmm0\n\t"
		"movq 13(%1), %%rax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movq %%rax, 13(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"22:\n\t" /* size = 22 */
		"vmovups (%1), %%xmm0\n\t"
		"movq 14(%1), %%rax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movq %%rax, 14(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"23:\n\t" /* size = 23 */
		"vmovups (%1), %%xmm0\n\t"
		"movq 15(%1), %%rax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movq %%rax, 15(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"24:\n\t" /* size = 24 */
		"vmovups (%1), %%xmm0\n\t"
		"movq 16(%1), %%rax\n\t"
		"vmovups %%xmm0, (%0)\n\t"
		"movq %%rax, 16(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"25:\n\t" /* size = 25 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 9(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 9(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"26:\n\t" /* size = 26 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 10(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 10(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"27:\n\t" /* size = 27 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 11(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 11(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"28:\n\t" /* size = 28 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 12(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 12(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"29:\n\t" /* size = 29 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 13(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 13(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"30:\n\t" /* size = 30 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 14(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 14(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"31:\n\t" /* size = 31 */
		"vmovups (%1), %%xmm1\n\t"
		"vmovups 15(%1), %%xmm0\n\t"
		"vmovups %%xmm1, (%0)\n\t"
		"vmovups %%xmm0, 15(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"32:\n\t" /* size = 32 */
		"vmovups (%1), %%ymm0\n\t"
		"vmovups %%ymm0, (%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"33:\n\t" /* size = 33 */
		"vmovups (%1), %%ymm0\n\t"
		"movzbl 32(%1), %%eax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movb %%al, 32(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"34:\n\t" /* size = 34 */
		"vmovups (%1), %%ymm0\n\t"
		"movzwl 32(%1), %%eax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movw %%ax, 32(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"35:\n\t" /* size = 35 */
		"vmovups (%1), %%ymm0\n\t"
		"movl 31(%1), %%eax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movl %%eax, 31(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"36:\n\t" /* size = 36 */
		"vmovups (%1), %%ymm0\n\t"
		"movl 32(%1), %%eax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movl %%eax, 32(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"37:\n\t" /* size = 37 */
		"vmovups (%1), %%ymm0\n\t"
		"movq 29(%1), %%rax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movq %%rax, 29(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"38:\n\t" /* size = 38 */
		"vmovups (%1), %%ymm0\n\t"
		"movq 30(%1), %%rax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movq %%rax, 30(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"39:\n\t" /* size = 39 */
		"vmovups (%1), %%ymm0\n\t"
		"movq 31(%1), %%rax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movq %%rax, 31(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"40:\n\t" /* size = 40 */
		"vmovups (%1), %%ymm0\n\t"
		"movq 32(%1), %%rax\n\t"
		"vmovups %%ymm0, (%0)\n\t"
		"movq %%rax, 32(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"41:\n\t" /* size = 41 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 25(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 25(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"42:\n\t" /* size = 42 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 26(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 26(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"43:\n\t" /* size = 43 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 27(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 27(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"44:\n\t" /* size = 44 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 28(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 28(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"45:\n\t" /* size = 45 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 29(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 29(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"46:\n\t" /* size = 46 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 30(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 30(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"47:\n\t" /* size = 47 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 31(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 31(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"48:\n\t" /* size = 48 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%xmm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%xmm0, 32(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"49:\n\t" /* size = 49 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 17(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 17(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"50:\n\t" /* size = 50 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 18(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 18(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"51:\n\t" /* size = 51 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 19(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 19(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"52:\n\t" /* size = 52 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 20(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 20(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"53:\n\t" /* size = 53 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 21(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 21(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"54:\n\t" /* size = 54 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 22(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 22(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"55:\n\t" /* size = 55 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 23(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 23(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"56:\n\t" /* size = 56 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 24(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 24(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"57:\n\t" /* size = 57 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 25(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 25(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"58:\n\t" /* size = 58 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 26(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 26(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"59:\n\t" /* size = 59 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 27(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 27(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"60:\n\t" /* size = 60 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 28(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 28(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"61:\n\t" /* size = 61 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 29(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 29(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"62:\n\t" /* size = 62 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 30(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 30(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"63:\n\t" /* size = 63 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 31(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 31(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"64:\n\t" /* size = 64 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"65:\n\t" /* size = 65 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movzbl 64(%1), %%eax\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"movb %%al, 64(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"66:\n\t" /* size = 66 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movzwl 64(%1), %%eax\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"movw %%ax, 64(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"67:\n\t" /* size = 67 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movl 63(%1), %%eax\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"movl %%eax, 63(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"68:\n\t" /* size = 68 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movl 64(%1), %%eax\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"movl %%eax, 64(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"69:\n\t" /* size = 69 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movq 61(%1), %%rax\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"movq %%rax, 61(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"70:\n\t" /* size = 70 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movq 62(%1), %%rax\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"movq %%rax, 62(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"71:\n\t" /* size = 71 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movq 63(%1), %%rax\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"movq %%rax, 63(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"72:\n\t" /* size = 72 */
		"vmovups (%1), %%ymm1\n\t"
		"vmovups 32(%1), %%ymm0\n\t"
		"movq 64(%1), %%rax\n\t"
		"vmovups %%ymm1, (%0)\n\t"
		"vmovups %%ymm0, 32(%0)\n\t"
		"movq %%rax, 64(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"73:\n\t" /* size = 73 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 57(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 57(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"74:\n\t" /* size = 74 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 58(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 58(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"75:\n\t" /* size = 75 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 59(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 59(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"76:\n\t" /* size = 76 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 60(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 60(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"77:\n\t" /* size = 77 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 61(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 61(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"78:\n\t" /* size = 78 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 62(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 62(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"79:\n\t" /* size = 79 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 63(%1), %%xmm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%xmm0, 63(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"80:\n\t" /* size = 80 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 64(%1), %%xmm0\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%xmm0, 64(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"81:\n\t" /* size = 81 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 49(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 49(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"82:\n\t" /* size = 82 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 50(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 50(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"83:\n\t" /* size = 83 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 51(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 51(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"84:\n\t" /* size = 84 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 52(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 52(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"85:\n\t" /* size = 85 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 53(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 53(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"86:\n\t" /* size = 86 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 54(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 54(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"87:\n\t" /* size = 87 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 55(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 55(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"88:\n\t" /* size = 88 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 56(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 56(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"89:\n\t" /* size = 89 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 57(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 57(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"90:\n\t" /* size = 90 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 58(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 58(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"91:\n\t" /* size = 91 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 59(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 59(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"92:\n\t" /* size = 92 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 60(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 60(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"93:\n\t" /* size = 93 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 61(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 61(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"94:\n\t" /* size = 94 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 62(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 62(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"95:\n\t" /* size = 95 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 63(%1), %%ymm0\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm0, 63(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		"96:\n\t" /* size = 96 */
		"vmovups (%1), %%ymm2\n\t"
		"vmovups 32(%1), %%ymm1\n\t"
		"vmovups 64(%1), %%ymm0\n\t"
		"vmovups %%ymm2, (%0)\n\t"
		"vmovups %%ymm1, 32(%0)\n\t"
		"vmovups %%ymm0, 64(%0)\n\t"
#if !defined(FASTCPY_NO_VZEROUPPER)
		"vzeroupper\n\t"
#endif
		"ret\n\t"
		".p2align 5\n\t"
		:: "r"(dest), "r"(src), "r"(size)
		: "rax","r9","ymm0","ymm1","ymm2","memory"
	);
#if defined(FASTCPY_USE_CMOV)
	_AVX_fastcpy_big(dest, src, size);
#endif
}


__attribute__((optimize("align-functions=32"),target("arch=x86-64-v2"))) void _SSE_fastcpy_tiny(void *dest, const void* src, size_t size) {
	asm volatile(
		"0:\n\t" /* size = 0 */
		"ret\n\t"
		".p2align 5\n\t"
		"1:\n\t" /* size = 1 */
		"movzbl (%1), %%eax\n\t"
		"movb %%al, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"2:\n\t" /* size = 2 */
		"movzwl (%1), %%eax\n\t"
		"movw %%ax, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"3:\n\t" /* size = 3 */
		"movzwl (%1), %%r9d\n\t"
		"movzbl 2(%1), %%eax\n\t"
		"movw %%r9w, (%0)\n\t"
		"movb %%al, 2(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"4:\n\t" /* size = 4 */
		"movl (%1), %%eax\n\t"
		"movl %%eax, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"5:\n\t" /* size = 5 */
		"movl (%1), %%r9d\n\t"
		"movzbl 4(%1), %%eax\n\t"
		"movl %%r9d, (%0)\n\t"
		"movb %%al, 4(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"6:\n\t" /* size = 6 */
		"movl (%1), %%r9d\n\t"
		"movzwl 4(%1), %%eax\n\t"
		"movl %%r9d, (%0)\n\t"
		"movw %%ax, 4(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"7:\n\t" /* size = 7 */
		"movl (%1), %%r9d\n\t"
		"movl 3(%1), %%eax\n\t"
		"movl %%r9d, (%0)\n\t"
		"movl %%eax, 3(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"8:\n\t" /* size = 8 */
		"movq (%1), %%rax\n\t"
		"movq %%rax, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"9:\n\t" /* size = 9 */
		"movq (%1), %%r9\n\t"
		"movzbl 8(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movb %%al, 8(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"10:\n\t" /* size = 10 */
		"movq (%1), %%r9\n\t"
		"movzwl 8(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movw %%ax, 8(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"11:\n\t" /* size = 11 */
		"movq (%1), %%r9\n\t"
		"movl 7(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movl %%eax, 7(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"12:\n\t" /* size = 12 */
		"movq (%1), %%r9\n\t"
		"movl 8(%1), %%eax\n\t"
		"movq %%r9, (%0)\n\t"
		"movl %%eax, 8(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"13:\n\t" /* size = 13 */
		"movq (%1), %%r9\n\t"
		"movq 5(%1), %%rax\n\t"
		"movq %%r9, (%0)\n\t"
		"movq %%rax, 5(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"14:\n\t" /* size = 14 */
		"movq (%1), %%r9\n\t"
		"movq 6(%1), %%rax\n\t"
		"movq %%r9, (%0)\n\t"
		"movq %%rax, 6(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"15:\n\t" /* size = 15 */
		"movq (%1), %%r9\n\t"
		"movq 7(%1), %%rax\n\t"
		"movq %%r9, (%0)\n\t"
		"movq %%rax, 7(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"16:\n\t" /* size = 16 */
		"movups (%1), %%xmm0\n\t"
		"movups %%xmm0, (%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"17:\n\t" /* size = 17 */
		"movups (%1), %%xmm0\n\t"
		"movzbl 16(%1), %%eax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movb %%al, 16(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"18:\n\t" /* size = 18 */
		"movups (%1), %%xmm0\n\t"
		"movzwl 16(%1), %%eax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movw %%ax, 16(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"19:\n\t" /* size = 19 */
		"movups (%1), %%xmm0\n\t"
		"movl 15(%1), %%eax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movl %%eax, 15(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"20:\n\t" /* size = 20 */
		"movups (%1), %%xmm0\n\t"
		"movl 16(%1), %%eax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movl %%eax, 16(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"21:\n\t" /* size = 21 */
		"movups (%1), %%xmm0\n\t"
		"movq 13(%1), %%rax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movq %%rax, 13(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"22:\n\t" /* size = 22 */
		"movups (%1), %%xmm0\n\t"
		"movq 14(%1), %%rax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movq %%rax, 14(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"23:\n\t" /* size = 23 */
		"movups (%1), %%xmm0\n\t"
		"movq 15(%1), %%rax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movq %%rax, 15(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"24:\n\t" /* size = 24 */
		"movups (%1), %%xmm0\n\t"
		"movq 16(%1), %%rax\n\t"
		"movups %%xmm0, (%0)\n\t"
		"movq %%rax, 16(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"25:\n\t" /* size = 25 */
		"movups (%1), %%xmm1\n\t"
		"movups 9(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 9(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"26:\n\t" /* size = 26 */
		"movups (%1), %%xmm1\n\t"
		"movups 10(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 10(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"27:\n\t" /* size = 27 */
		"movups (%1), %%xmm1\n\t"
		"movups 11(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 11(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"28:\n\t" /* size = 28 */
		"movups (%1), %%xmm1\n\t"
		"movups 12(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 12(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"29:\n\t" /* size = 29 */
		"movups (%1), %%xmm1\n\t"
		"movups 13(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 13(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"30:\n\t" /* size = 30 */
		"movups (%1), %%xmm1\n\t"
		"movups 14(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 14(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"31:\n\t" /* size = 31 */
		"movups (%1), %%xmm1\n\t"
		"movups 15(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 15(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"32:\n\t" /* size = 32 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"33:\n\t" /* size = 33 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movzbl 32(%1), %%eax\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movb %%al, 32(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"34:\n\t" /* size = 34 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movzwl 32(%1), %%eax\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movw %%ax, 32(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"35:\n\t" /* size = 35 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movl 31(%1), %%eax\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movl %%eax, 31(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"36:\n\t" /* size = 36 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movl 32(%1), %%eax\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movl %%eax, 32(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"37:\n\t" /* size = 37 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movq 29(%1), %%rax\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movq %%rax, 29(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"38:\n\t" /* size = 38 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movq 30(%1), %%rax\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movq %%rax, 30(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"39:\n\t" /* size = 39 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movq 31(%1), %%rax\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movq %%rax, 31(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"40:\n\t" /* size = 40 */
		"movups (%1), %%xmm1\n\t"
		"movups 16(%1), %%xmm0\n\t"
		"movq 32(%1), %%rax\n\t"
		"movups %%xmm1, (%0)\n\t"
		"movups %%xmm0, 16(%0)\n\t"
		"movq %%rax, 32(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"41:\n\t" /* size = 41 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 25(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 25(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"42:\n\t" /* size = 42 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 26(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 26(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"43:\n\t" /* size = 43 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 27(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 27(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"44:\n\t" /* size = 44 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 28(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 28(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"45:\n\t" /* size = 45 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 29(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 29(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"46:\n\t" /* size = 46 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 30(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 30(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"47:\n\t" /* size = 47 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 31(%1), %%xmm0\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 31(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"48:\n\t" /* size = 48 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"49:\n\t" /* size = 49 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movzbl 48(%1), %%eax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movb %%al, 48(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"50:\n\t" /* size = 50 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movzwl 48(%1), %%eax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movw %%ax, 48(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"51:\n\t" /* size = 51 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movl 47(%1), %%eax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movl %%eax, 47(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"52:\n\t" /* size = 52 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movl 48(%1), %%eax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movl %%eax, 48(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"53:\n\t" /* size = 53 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movq 45(%1), %%rax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movq %%rax, 45(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"54:\n\t" /* size = 54 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movq 46(%1), %%rax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movq %%rax, 46(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"55:\n\t" /* size = 55 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movq 47(%1), %%rax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movq %%rax, 47(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"56:\n\t" /* size = 56 */
		"movups (%1), %%xmm2\n\t"
		"movups 16(%1), %%xmm1\n\t"
		"movups 32(%1), %%xmm0\n\t"
		"movq 48(%1), %%rax\n\t"
		"movups %%xmm2, (%0)\n\t"
		"movups %%xmm1, 16(%0)\n\t"
		"movups %%xmm0, 32(%0)\n\t"
		"movq %%rax, 48(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"57:\n\t" /* size = 57 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 41(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 41(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"58:\n\t" /* size = 58 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 42(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 42(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"59:\n\t" /* size = 59 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 43(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 43(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"60:\n\t" /* size = 60 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 44(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 44(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"61:\n\t" /* size = 61 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 45(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 45(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"62:\n\t" /* size = 62 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 46(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 46(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"63:\n\t" /* size = 63 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 47(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm0, 47(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		"64:\n\t" /* size = 64 */
		"movups (%1), %%xmm3\n\t"
		"movups 16(%1), %%xmm2\n\t"
		"movups 32(%1), %%xmm1\n\t"
		"movups 48(%1), %%xmm0\n\t"
		"movups %%xmm3, (%0)\n\t"
		"movups %%xmm2, 16(%0)\n\t"
		"movups %%xmm1, 32(%0)\n\t"
		"movups %%xmm0, 48(%0)\n\t"
		"ret\n\t"
		".p2align 5\n\t"
		:: "r"(dest), "r"(src), "r"(size)
		: "rax","r9","xmm0","xmm1","xmm2","xmm3","memory"
	);
#if defined(FASTCPY_USE_CMOV)
	_SSE_fastcpy_big(dest, src, size);
#endif
}

