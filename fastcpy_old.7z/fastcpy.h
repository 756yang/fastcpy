﻿#ifndef LIB_FAST_CPY_H
#define LIB_FAST_CPY_H

#ifndef LIBRARY_GLOBAL_H
#define LIBRARY_GLOBAL_H

#if defined(_MSC_VER) || defined(WIN64) || defined(_WIN64) || defined(__WIN64__) || defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#  define Q_DECL_EXPORT __declspec(dllexport)
#  define Q_DECL_IMPORT __declspec(dllimport)
#else
#  define Q_DECL_EXPORT     __attribute__((visibility("default")))
#  define Q_DECL_IMPORT     __attribute__((visibility("default")))
#endif

#if defined(FASTCPY_SHARED_LIBRARY)
#  define FASTCPY_EXPORT Q_DECL_EXPORT
#elif defined(FASTCPY_STATIC_LIBRARY) || defined(FASTCPY_OWNER_SOURCE)
#  define FASTCPY_EXPORT
#else
#  define FASTCPY_EXPORT Q_DECL_IMPORT
#endif

#endif // LIBRARY_GLOBAL_H

#include <stddef.h>
#if !defined(__AVX__) && !defined(__SSE__)
#error "You platform must support SSE!"
#endif


#ifdef __cplusplus
extern "C"
{
#endif

#if !defined(FASTCPY_USE_CMOV)
/* AVX 版本的 fastcpy_big 实现, 用于内联函数, 禁止外部调用 */
FASTCPY_EXPORT void* _AVX_fastcpy_big(void *dest, const void* src, size_t size);

/* SSE 版本的 fastcpy_big 实现, 用于内联函数, 禁止外部调用 */
FASTCPY_EXPORT void* _SSE_fastcpy_big(void *dest, const void* src, size_t size);
#endif

/* AVX 版本的 fastcpy_tiny 实现, 用于内联函数, 禁止外部调用 */
FASTCPY_EXPORT void _AVX_fastcpy_tiny(void *dest, const void* src, size_t size);

/* SSE 版本的 fastcpy_tiny 实现, 用于内联函数, 禁止外部调用 */
FASTCPY_EXPORT void _SSE_fastcpy_tiny(void *dest, const void* src, size_t size);

#ifdef __cplusplus
}
#endif

#ifdef FASTCPY_OWNER_SOURCE
void* fastcpy_tiny(void *dest, const void* src, size_t size);
#endif

/**
 * amd64 平台最快的 memcpy 实现
 * 若平台支持 AVX 指令 则当 size <= 96 有额外优化(等效于多个 mov 指令)
 * 否则平台支持 SSE 指令 则当 size <= 64 有额外优化(等效于多个 mov 指令)
 * 若 size 已知且小于 请使用编译器提供的 memcpy 这可以减少一个 call 指令
 * 若 size 编译时无法确定, 则使用此函数优于编译器提供版本
 */
inline void* fastcpy(void *dest, const void* src, size_t size) {
#ifdef __AVX__
#if !defined(FASTCPY_USE_CMOV)/* 可预测情况下, 分支优于 cmov 指令 */
	if(size <= 96) {
		void (*fn)(void*, const void*, size_t);
		char *fn_addr = (char*)&_AVX_fastcpy_tiny + 32 * size;
		fn = (void (*)(void*, const void*, size_t))fn_addr;
		fn(dest, src, size);
	}
	else return _AVX_fastcpy_big(dest, src, size);
#else/* 条件运算符会生成 cmov 指令 */
	void (*fn)(void*, const void*, size_t);
	char *fn_addr = (char*)&_AVX_fastcpy_tiny + 32 * (size > 97 ? 97 : size);
	fn = (void (*)(void*, const void*, size_t))fn_addr;
	fn(dest, src, size);
#endif
#else
#if !defined(FASTCPY_USE_CMOV)
	if(size <= 64) {
		void (*fn)(void*, const void*, size_t);
		char *fn_addr = (char*)&_SSE_fastcpy_tiny + 32 * size;
		fn = (void (*)(void*, const void*, size_t))fn_addr;
		fn(dest, src, size);
	}
	else return _SSE_fastcpy_big(dest, src, size);
#else
	void (*fn)(void*, const void*, size_t);
	char *fn_addr = (char*)&_SSE_fastcpy_tiny + 32 * (size > 65 ? 65 : size);
	fn = (void (*)(void*, const void*, size_t))fn_addr;
	fn(dest, src, size);
#endif
#endif
	return dest;
}

#endif // LIB_FAST_CPY_H
