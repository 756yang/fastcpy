﻿#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <immintrin.h>

/* 此文件是用于测试 fastcpy 性能, 构建 fastcpy 库无需此文件 */

#if 1
#define JUMP_TABLE_BREAK break
#else
#define JUMP_TABLE_BREAK asm volatile("ret":::"memory")
#endif

#ifdef FASTCPY_OWNER_SOURCE
void* fastcpy_tiny(void *dest, const void* src, size_t size) {
	uint8_t *pdest = (uint8_t*)dest, *psrc = (uint8_t*)src;
	uint8_t u8;
	uint16_t u16;
	uint32_t m4a, m4b;
	uint64_t m8a, m8b;
	__m128 m16a, m16b, m16c, m16d;
	__m256 m32a, m32b, m32c, m32d;
	switch(size) {
	case 0:
		JUMP_TABLE_BREAK;
	case 1:
		u8 = *(uint8_t*)psrc;
		*(uint8_t*)pdest = u8;
		JUMP_TABLE_BREAK;
	case 2:
		u16 = *(uint16_t*)psrc;
		*(uint16_t*)pdest = u16;
		JUMP_TABLE_BREAK;
	case 3:
		u16 = *(uint16_t*)psrc;
		u8 = *(uint8_t*)(psrc + 2);
		*(uint16_t*)pdest = u16;
		*(uint8_t*)(pdest + 2) = u8;
		JUMP_TABLE_BREAK;
	case 4:
		m4a = *(uint32_t*)psrc;
		*(uint32_t*)pdest = m4a;
		JUMP_TABLE_BREAK;
	case 5:
		m4a = *(uint32_t*)psrc;
		u8 = *(uint8_t*)(psrc + 4);
		*(uint32_t*)pdest = m4a;
		*(uint8_t*)(pdest + 4) = u8;
		JUMP_TABLE_BREAK;
	case 6:
		m4a = *(uint32_t*)psrc;
		u16 = *(uint16_t*)(psrc + 4);
		*(uint32_t*)pdest = m4a;
		*(uint16_t*)(pdest + 4) = u16;
		JUMP_TABLE_BREAK;
	case 7:
		m4a = *(uint32_t*)psrc;
		m4b = *(uint32_t*)(psrc + 3);
		*(uint32_t*)pdest = m4a;
		*(uint32_t*)(pdest + 3) = m4b;
		JUMP_TABLE_BREAK;
	case 8:
		m8a = *(uint64_t*)psrc;
		*(uint64_t*)pdest = m8a;
		JUMP_TABLE_BREAK;
	case 9:
		m8a = *(uint64_t*)psrc;
		u8 = *(uint8_t*)(psrc + 8);
		*(uint64_t*)pdest = m8a;
		*(uint8_t*)(pdest + 8) = u8;
		JUMP_TABLE_BREAK;
	case 10:
		m8a = *(uint64_t*)psrc;
		u16 = *(uint16_t*)(psrc + 8);
		*(uint64_t*)pdest = m8a;
		*(uint16_t*)(pdest + 8) = u16;
		JUMP_TABLE_BREAK;
	case 11:
		m8a = *(uint64_t*)psrc;
		m4a = *(uint32_t*)(psrc + 7);
		*(uint64_t*)pdest = m8a;
		*(uint32_t*)(pdest + 7) = m4a;
		JUMP_TABLE_BREAK;
	case 12:
		m8a = *(uint64_t*)psrc;
		m4a = *(uint32_t*)(psrc + 8);
		*(uint64_t*)pdest = m8a;
		*(uint32_t*)(pdest + 8) = m4a;
		JUMP_TABLE_BREAK;
	case 13:
		m8a = *(uint64_t*)psrc;
		m8b = *(uint64_t*)(psrc + 5);
		*(uint64_t*)pdest = m8a;
		*(uint64_t*)(pdest + 5) = m8b;
		JUMP_TABLE_BREAK;
	case 14:
		m8a = *(uint64_t*)psrc;
		m8b = *(uint64_t*)(psrc + 6);
		*(uint64_t*)pdest = m8a;
		*(uint64_t*)(pdest + 6) = m8b;
		JUMP_TABLE_BREAK;
	case 15:
		m8a = *(uint64_t*)psrc;
		m8b = *(uint64_t*)(psrc + 7);
		*(uint64_t*)pdest = m8a;
		*(uint64_t*)(pdest + 7) = m8b;
		JUMP_TABLE_BREAK;
	case 16:
		m16a = _mm_loadu_ps((float*)psrc);
		_mm_storeu_ps((float*)pdest, m16a);
		JUMP_TABLE_BREAK;
	case 17:
		m16a = _mm_loadu_ps((float*)psrc);
		u8 = *(uint8_t*)(psrc + 16);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint8_t*)(pdest + 16) = u8;
		JUMP_TABLE_BREAK;
	case 18:
		m16a = _mm_loadu_ps((float*)psrc);
		u16 = *(uint16_t*)(psrc + 16);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint16_t*)(pdest + 16) = u16;
		JUMP_TABLE_BREAK;
	case 19:
		m16a = _mm_loadu_ps((float*)psrc);
		m4a = *(uint32_t*)(psrc + 15);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint32_t*)(pdest + 15) = m4a;
		JUMP_TABLE_BREAK;
	case 20:
		m16a = _mm_loadu_ps((float*)psrc);
		m4a = *(uint32_t*)(psrc + 16);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint32_t*)(pdest + 16) = m4a;
		JUMP_TABLE_BREAK;
	case 21:
		m16a = _mm_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 13);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint64_t*)(pdest + 13) = m8a;
		JUMP_TABLE_BREAK;
	case 22:
		m16a = _mm_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 14);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint64_t*)(pdest + 14) = m8a;
		JUMP_TABLE_BREAK;
	case 23:
		m16a = _mm_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 15);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint64_t*)(pdest + 15) = m8a;
		JUMP_TABLE_BREAK;
	case 24:
		m16a = _mm_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 16);
		_mm_storeu_ps((float*)pdest, m16a);
		*(uint64_t*)(pdest + 16) = m8a;
		JUMP_TABLE_BREAK;
	case 25:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 9));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 9), m16b);
		JUMP_TABLE_BREAK;
	case 26:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 10));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 10), m16b);
		JUMP_TABLE_BREAK;
	case 27:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 11));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 11), m16b);
		JUMP_TABLE_BREAK;
	case 28:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 12));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 12), m16b);
		JUMP_TABLE_BREAK;
	case 29:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 13));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 13), m16b);
		JUMP_TABLE_BREAK;
	case 30:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 14));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 14), m16b);
		JUMP_TABLE_BREAK;
	case 31:
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 15));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 15), m16b);
		JUMP_TABLE_BREAK;
	case 32:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		JUMP_TABLE_BREAK;
	case 33:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		u8 = *(uint8_t*)(psrc + 32);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		u8 = *(uint8_t*)(psrc + 32);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint8_t*)(pdest + 32) = u8;
		JUMP_TABLE_BREAK;
	case 34:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		u16 = *(uint16_t*)(psrc + 32);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		u16 = *(uint16_t*)(psrc + 32);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint16_t*)(pdest + 32) = u16;
		JUMP_TABLE_BREAK;
	case 35:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m4a = *(uint32_t*)(psrc + 31);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m4a = *(uint32_t*)(psrc + 31);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint32_t*)(pdest + 31) = m4a;
		JUMP_TABLE_BREAK;
	case 36:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m4a = *(uint32_t*)(psrc + 32);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m4a = *(uint32_t*)(psrc + 32);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint32_t*)(pdest + 32) = m4a;
		JUMP_TABLE_BREAK;
	case 37:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 29);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m8a = *(uint64_t*)(psrc + 29);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint64_t*)(pdest + 29) = m8a;
		JUMP_TABLE_BREAK;
	case 38:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 30);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m8a = *(uint64_t*)(psrc + 30);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint64_t*)(pdest + 30) = m8a;
		JUMP_TABLE_BREAK;
	case 39:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 31);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m8a = *(uint64_t*)(psrc + 31);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint64_t*)(pdest + 31) = m8a;
		JUMP_TABLE_BREAK;
	case 40:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m8a = *(uint64_t*)(psrc + 32);
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m8a = *(uint64_t*)(psrc + 32);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
#endif
		*(uint64_t*)(pdest + 32) = m8a;
		JUMP_TABLE_BREAK;
	case 41:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 25));
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 25));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 25), m16a);
		JUMP_TABLE_BREAK;
	case 42:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 26));
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 26));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 26), m16a);
		JUMP_TABLE_BREAK;
	case 43:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 27));
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 27));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 27), m16a);
		JUMP_TABLE_BREAK;
	case 44:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 28));
		_mm256_storeu_ps((float*)pdest, m32a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 28));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 28), m16a);
		JUMP_TABLE_BREAK;
	case 45:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 29));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm_storeu_ps((float*)(pdest + 29), m16a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 29));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 29), m16a);
		JUMP_TABLE_BREAK;
	case 46:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 30));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm_storeu_ps((float*)(pdest + 30), m16a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 30));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 30), m16a);
		JUMP_TABLE_BREAK;
	case 47:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 31));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm_storeu_ps((float*)(pdest + 31), m16a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 31));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 31), m16a);
		JUMP_TABLE_BREAK;
	case 48:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m16a = _mm_loadu_ps((float*)(psrc + 32));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm_storeu_ps((float*)(pdest + 32), m16a);
#else
		m16b = _mm_loadu_ps((float*)psrc);
		m16c = _mm_loadu_ps((float*)(psrc + 16));
		m16a = _mm_loadu_ps((float*)(psrc + 32));
		_mm_storeu_ps((float*)pdest, m16b);
		_mm_storeu_ps((float*)(pdest + 16), m16c);
#endif
		_mm_storeu_ps((float*)(pdest + 32), m16a);
		JUMP_TABLE_BREAK;
	case 49:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 17));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 17), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		u8 = *(uint8_t*)(psrc + 48);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint8_t*)(pdest + 48) = u8;
#endif
		JUMP_TABLE_BREAK;
	case 50:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 18));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 18), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		u16 = *(uint16_t*)(psrc + 48);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint16_t*)(pdest + 48) = u16;
#endif
		JUMP_TABLE_BREAK;
	case 51:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 19));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 19), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m4a = *(uint32_t*)(psrc + 47);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint32_t*)(pdest + 47) = m4a;
#endif
		JUMP_TABLE_BREAK;
	case 52:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 20));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 20), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m4a = *(uint32_t*)(psrc + 48);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint32_t*)(pdest + 48) = m4a;
#endif
		JUMP_TABLE_BREAK;
	case 53:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 21));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 21), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 45);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint64_t*)(pdest + 45) = m8a;
#endif
		JUMP_TABLE_BREAK;
	case 54:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 22));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 22), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 46);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint64_t*)(pdest + 46) = m8a;
#endif
		JUMP_TABLE_BREAK;
	case 55:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 23));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 23), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 47);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint64_t*)(pdest + 47) = m8a;
#endif
		JUMP_TABLE_BREAK;
	case 56:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 24));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 24), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 48);
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		*(uint64_t*)(pdest + 48) = m8a;
#endif
		JUMP_TABLE_BREAK;
	case 57:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 25));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 25), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 41));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 41), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 58:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 26));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 26), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 42));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 42), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 59:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 27));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 27), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 43));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 43), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 60:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 28));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 28), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 44));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 44), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 61:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 29));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 29), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 45));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 45), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 62:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 30));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 30), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 46));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 46), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 63:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 31));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 31), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 47));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 47), m16d);
#endif
		JUMP_TABLE_BREAK;
	case 64:
#ifdef __AVX__
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
#else
		m16a = _mm_loadu_ps((float*)psrc);
		m16b = _mm_loadu_ps((float*)(psrc + 16));
		m16c = _mm_loadu_ps((float*)(psrc + 32));
		m16d = _mm_loadu_ps((float*)(psrc + 48));
		_mm_storeu_ps((float*)pdest, m16a);
		_mm_storeu_ps((float*)(pdest + 16), m16b);
		_mm_storeu_ps((float*)(pdest + 32), m16c);
		_mm_storeu_ps((float*)(pdest + 48), m16d);
#endif
		JUMP_TABLE_BREAK;
#ifdef __AVX__
	case 65:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		u8 = *(uint8_t*)(psrc + 64);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint8_t*)(pdest + 64) = u8;
		JUMP_TABLE_BREAK;
	case 66:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		u16 = *(uint16_t*)(psrc + 64);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint16_t*)(pdest + 64) = u16;
		JUMP_TABLE_BREAK;
	case 67:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m4a = *(uint32_t*)(psrc + 63);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint32_t*)(pdest + 63) = m4a;
		JUMP_TABLE_BREAK;
	case 68:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m4a = *(uint32_t*)(psrc + 64);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint32_t*)(pdest + 64) = m4a;
		JUMP_TABLE_BREAK;
	case 69:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 61);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint64_t*)(pdest + 61) = m8a;
		JUMP_TABLE_BREAK;
	case 70:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 62);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint64_t*)(pdest + 62) = m8a;
		JUMP_TABLE_BREAK;
	case 71:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 63);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint64_t*)(pdest + 63) = m8a;
		JUMP_TABLE_BREAK;
	case 72:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m8a = *(uint64_t*)(psrc + 64);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		*(uint64_t*)(pdest + 64) = m8a;
		JUMP_TABLE_BREAK;
	case 73:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 57));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 57), m16a);
		JUMP_TABLE_BREAK;
	case 74:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 58));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 58), m16a);
		JUMP_TABLE_BREAK;
	case 75:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 59));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 59), m16a);
		JUMP_TABLE_BREAK;
	case 76:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 60));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 60), m16a);
		JUMP_TABLE_BREAK;
	case 77:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 61));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 61), m16a);
		JUMP_TABLE_BREAK;
	case 78:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 62));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 62), m16a);
		JUMP_TABLE_BREAK;
	case 79:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 63));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 63), m16a);
		JUMP_TABLE_BREAK;
	case 80:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m16a = _mm_loadu_ps((float*)(psrc + 64));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm_storeu_ps((float*)(pdest + 64), m16a);
		JUMP_TABLE_BREAK;
	case 81:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 49));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 49), m32c);
		JUMP_TABLE_BREAK;
	case 82:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 50));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 50), m32c);
		JUMP_TABLE_BREAK;
	case 83:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 51));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 51), m32c);
		JUMP_TABLE_BREAK;
	case 84:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 52));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 52), m32c);
		JUMP_TABLE_BREAK;
	case 85:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 53));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 53), m32c);
		JUMP_TABLE_BREAK;
	case 86:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 54));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 54), m32c);
		JUMP_TABLE_BREAK;
	case 87:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 55));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 55), m32c);
		JUMP_TABLE_BREAK;
	case 88:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 56));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 56), m32c);
		JUMP_TABLE_BREAK;
	case 89:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 57));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 57), m32c);
		JUMP_TABLE_BREAK;
	case 90:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 58));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 58), m32c);
		JUMP_TABLE_BREAK;
	case 91:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 59));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 59), m32c);
		JUMP_TABLE_BREAK;
	case 92:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 60));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 60), m32c);
		JUMP_TABLE_BREAK;
	case 93:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 61));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 61), m32c);
		JUMP_TABLE_BREAK;
	case 94:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 62));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 62), m32c);
		JUMP_TABLE_BREAK;
	case 95:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 63));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 63), m32c);
		JUMP_TABLE_BREAK;
	case 96:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		JUMP_TABLE_BREAK;
	case 97:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		u8 = *(uint8_t*)(psrc + 96);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint8_t*)(pdest + 96) = u8;
		JUMP_TABLE_BREAK;
	case 98:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		u16 = *(uint16_t*)(psrc + 96);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint16_t*)(pdest + 96) = u16;
		JUMP_TABLE_BREAK;
	case 99:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m4a = *(uint32_t*)(psrc + 95);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint32_t*)(pdest + 95) = m4a;
		JUMP_TABLE_BREAK;
	case 100:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m4a = *(uint32_t*)(psrc + 96);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint32_t*)(pdest + 96) = m4a;
		JUMP_TABLE_BREAK;
	case 101:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m8a = *(uint64_t*)(psrc + 93);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint64_t*)(pdest + 93) = m8a;
		JUMP_TABLE_BREAK;
	case 102:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m8a = *(uint64_t*)(psrc + 94);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint64_t*)(pdest + 94) = m8a;
		JUMP_TABLE_BREAK;
	case 103:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m8a = *(uint64_t*)(psrc + 95);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint64_t*)(pdest + 95) = m8a;
		JUMP_TABLE_BREAK;
	case 104:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m8a = *(uint64_t*)(psrc + 96);
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		*(uint64_t*)(pdest + 96) = m8a;
		JUMP_TABLE_BREAK;
	case 105:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 89));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 89), m16a);
		JUMP_TABLE_BREAK;
	case 106:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 90));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 90), m16a);
		JUMP_TABLE_BREAK;
	case 107:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 91));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 91), m16a);
		JUMP_TABLE_BREAK;
	case 108:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 92));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 92), m16a);
		JUMP_TABLE_BREAK;
	case 109:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 93));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 93), m16a);
		JUMP_TABLE_BREAK;
	case 110:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 94));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 94), m16a);
		JUMP_TABLE_BREAK;
	case 111:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 95));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 95), m16a);
		JUMP_TABLE_BREAK;
	case 112:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m16a = _mm_loadu_ps((float*)(psrc + 96));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm_storeu_ps((float*)(pdest + 96), m16a);
		JUMP_TABLE_BREAK;
	case 113:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 81));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 81), m32d);
		JUMP_TABLE_BREAK;
	case 114:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 82));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 82), m32d);
		JUMP_TABLE_BREAK;
	case 115:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 83));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 83), m32d);
		JUMP_TABLE_BREAK;
	case 116:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 84));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 84), m32d);
		JUMP_TABLE_BREAK;
	case 117:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 85));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 85), m32d);
		JUMP_TABLE_BREAK;
	case 118:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 86));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 86), m32d);
		JUMP_TABLE_BREAK;
	case 119:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 87));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 87), m32d);
		JUMP_TABLE_BREAK;
	case 120:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 88));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 88), m32d);
		JUMP_TABLE_BREAK;
	case 121:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 89));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 89), m32d);
		JUMP_TABLE_BREAK;
	case 122:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 90));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 90), m32d);
		JUMP_TABLE_BREAK;
	case 123:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 91));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 91), m32d);
		JUMP_TABLE_BREAK;
	case 124:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 92));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 92), m32d);
		JUMP_TABLE_BREAK;
	case 125:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 93));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 93), m32d);
		JUMP_TABLE_BREAK;
	case 126:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 94));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 94), m32d);
		JUMP_TABLE_BREAK;
	case 127:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 95));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 95), m32d);
		JUMP_TABLE_BREAK;
	case 128:
		m32a = _mm256_loadu_ps((float*)psrc);
		m32b = _mm256_loadu_ps((float*)(psrc + 32));
		m32c = _mm256_loadu_ps((float*)(psrc + 64));
		m32d = _mm256_loadu_ps((float*)(psrc + 96));
		_mm256_storeu_ps((float*)pdest, m32a);
		_mm256_storeu_ps((float*)(pdest + 32), m32b);
		_mm256_storeu_ps((float*)(pdest + 64), m32c);
		_mm256_storeu_ps((float*)(pdest + 96), m32d);
		JUMP_TABLE_BREAK;
#endif
	default:
		return memcpy(dest, src, size);
	}
	return dest;
}
#endif

