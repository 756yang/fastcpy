﻿#include "fastcpy/fastcpy.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#define W 96
#define INLINE inline/*__attribute__((noinline))*/

inline int random(uint32_t *seed) {
	uint32_t desired = *seed = *seed * 214013 + 2531011;
	return (desired % 96) + 1;
}

inline uint64_t __read_timestamp() {
	uint32_t tsc, high;
	asm volatile("lfence\n\trdtsc" : "=a"(tsc), "=d"(high)::);
	return tsc + ((uint64_t)high << 32);
}

INLINE void copy_test0(void *dest, const void *src, size_t size) {
	memcpy(dest, src, size);
}

INLINE void copy_test1(void *dest, const void *src, size_t size) {
	fastcpy_tiny(dest, src, size);
}

INLINE void copy_test2(void *dest, const void *src, size_t size) {
	fastcpy(dest, src, size);
}

int main(int argc, char **argv) {
	uint32_t seed;
	const int size = 1024*1024*1024;
	char *src = (char*)malloc(size);
	char *dest = (char*)malloc(size);
	int i, j, *cw = (int*)malloc(size / W * 2 * sizeof(int));
	uint64_t old_time, new_time;
	for(seed = 0, i = 0; i < size / W * 2; ++i) cw[i] = random(&seed);
	memset(src, -1, size);
	for(i = 0; i < size; i += 1024) memcpy(dest + i, src + i, 1024);
	old_time = __read_timestamp();
	for(int k = 0; k < 16; ++k)
		for(i = 0, j = 0; i <= size - W; i += cw[j++])
			copy_test0(dest + i, src + i, cw[j]);
	new_time = __read_timestamp();
	printf("copy_test0 %llu\n", new_time - old_time);
	seed = 0;
	old_time = __read_timestamp();
	for(int k = 0; k < 16; ++k)
		for(i = 0, j = 0; i <= size - W; i += cw[j++])
			copy_test1(dest + i, src + i, cw[j]);
	new_time = __read_timestamp();
	printf("copy_test1 %llu\n", new_time - old_time);
	seed = 0;
	old_time = __read_timestamp();
	for(int k = 0; k < 16; ++k)
		for(i = 0, j = 0; i <= size - W; i += cw[j++])
			copy_test2(dest + i, src + i, cw[j]);
	new_time = __read_timestamp();
	printf("copy_test2 %llu\n", new_time - old_time);
	free(src);
	free(dest);
	free(cw);
	return 0;
}

